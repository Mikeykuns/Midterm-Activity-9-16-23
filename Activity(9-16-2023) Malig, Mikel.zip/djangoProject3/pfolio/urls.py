from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='pfolio-home'),
    path('about/', views.about, name='pfolio-about'),
    path('contact/', views.contact, name='pfolio-contact'),
]