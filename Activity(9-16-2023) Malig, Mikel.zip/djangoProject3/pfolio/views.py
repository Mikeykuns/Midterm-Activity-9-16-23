from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
posts = [
    {
        'author': 'Mikel Carlo Malig',
        'title': 'Home Page',
        'content': 'Welcome to my E-Portfolio, feel free to scan the webpages!.',
    }

]
def home (request):
    context = {
        'posts': posts
    }
    return render(request, 'pfolio/home.html', context)

def about (request):
    return render(request, 'pfolio/about.html')

def contact (request):
    return render(request, 'pfolio/contact.html')